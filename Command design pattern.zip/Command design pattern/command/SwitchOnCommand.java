public class SwitchOnCommand implements Commands
{
    Devices thisDevice;
    public SwitchOnCommand(Devices currentDevice)
    {
     thisDevice=currentDevice;
    }
    public void execute()
    {
    thisDevice.switchOn();
    }    
}