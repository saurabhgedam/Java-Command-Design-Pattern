public interface Commands
{    
    void execute();
}
