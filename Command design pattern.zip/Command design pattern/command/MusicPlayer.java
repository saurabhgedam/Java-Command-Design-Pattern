public class MusicPlayer implements Devices
{
    private int volume=0;    
    Commands anyCommand;
    public MusicPlayer(Commands commandsobject)
    {
    anyCommand=commandsobject; 
    }        
    public MusicPlayer()
    {
    }
    public void switchOn()
    {    
        System.out.println("Turning MusicPlayer on");               
    }
    public void switchOff()
    {
        System.out.println("Turning MusicPlayer off");     
    }
    public void volumeDown()
    {
        volume--;
        System.out.println("Decreasing volume.Current Volume is :" + volume);
    }
     public void volumeUp()
    {
        volume++;
        System.out.println("Increasing volume.Current Volume is :" + volume);
    }
}