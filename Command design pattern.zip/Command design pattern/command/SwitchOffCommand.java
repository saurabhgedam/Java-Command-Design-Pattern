public class SwitchOffCommand implements Commands
{
    Devices thisDevice;
    public SwitchOffCommand(Devices currentDevice)
    {
     thisDevice=currentDevice;
    }
    public void execute()
    {
    thisDevice.switchOff();
    }    
}