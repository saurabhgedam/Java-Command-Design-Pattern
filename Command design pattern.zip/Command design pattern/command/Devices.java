public interface Devices
{
    void volumeUp();
    void volumeDown();
    void switchOn();
    void switchOff();
}
