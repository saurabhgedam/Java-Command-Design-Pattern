public class VolumeUpCommand implements Commands
{
    Devices thisDevice;
    public VolumeUpCommand(Devices currentDevice)
    {
     thisDevice=currentDevice;
    }
    public void execute()
    {
    thisDevice.volumeUp();
    }    
}