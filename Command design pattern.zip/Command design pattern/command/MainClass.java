public class MainClass
{
    public static void main (String[] args)
    {    
     Tv tryingTV = new Tv();
     SwitchOnCommand tryingSwitchCommand = new SwitchOnCommand(tryingTV);
     InvokerRemoteControl tryingInvoker = new InvokerRemoteControl(tryingSwitchCommand);
     tryingInvoker.pressButton();
    }
}