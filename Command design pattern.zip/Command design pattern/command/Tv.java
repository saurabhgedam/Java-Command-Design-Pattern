public class Tv implements Devices
{
    int volume=0;
    
    public Tv()
    {
    }
    public void volumeUp()
    {
        volume++;
        System.out.println("Increasing volume. Current volume is: "+ volume);            
    }
    public void volumeDown()
    {
        volume--;
        System.out.println("Decreasing volume. Current volume is: " + volume);           
    }
    public void switchOn()
    {
        System.out.println("Tv is on");           
    }
    public void switchOff()
    {
        System.out.println("Tv is off");           
    }
}
