public class VolumeDownCommand implements Commands
{
    Devices thisDevice;
    public VolumeDownCommand(Devices currentDevice)
    {
     thisDevice=currentDevice;
    }
    public void execute()
    {
    thisDevice.volumeDown();
    }    
}