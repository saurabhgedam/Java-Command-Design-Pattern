public class Radio implements Devices
{
    private int volume=0;
    Commands anyCommand;
    public Radio(Commands commandsobject)
    {
        anyCommand=commandsobject;  
    }
    public Radio()
    {
    
    }
    public void switchOn()
    {    
        System.out.println("Turning Radio on");               
    }
    public void switchOff()
    {
        System.out.println("Turning Radio off");     
    }
    public void volumeDown()
    {
        volume--;
        System.out.println("Decreasing volume.Current Volume is :" + volume);
    }
     public void volumeUp()
    {
        volume++;
        System.out.println("Increasing volume.Current Volume is :" + volume);
    }
}