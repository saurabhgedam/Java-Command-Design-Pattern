public class InvokerRemoteControl
{
    Commands thisCommand;
    public InvokerRemoteControl(Commands currentRemoteCommand)
    {
    thisCommand=currentRemoteCommand;
    }    
    public void pressButton()
    {
    thisCommand.execute();
    }
}